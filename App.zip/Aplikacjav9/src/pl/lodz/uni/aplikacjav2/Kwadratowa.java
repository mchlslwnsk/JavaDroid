package pl.lodz.uni.aplikacjav2;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Kwadratowa extends Activity {
	Button zapiszwynik;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_kwadratowa);
		zapiszwynik = (Button)findViewById(R.id.buttonzapisz2);
	}
	//----------------------------------------------------------------------
	public void kwadratowa(View view){
		zapiszwynik = (Button)findViewById(R.id.buttonzapisz2);
		EditText para=(EditText)findViewById(R.id.editText1);
		EditText parb=(EditText)findViewById(R.id.editText2);
		EditText parc=(EditText)findViewById(R.id.editText3);
		EditText wynik=(EditText)findViewById(R.id.editText4);
		
		try {

			double aaa = Double.parseDouble(para.getText().toString());
            double bbb = Double.parseDouble(parb.getText().toString());
            double ccc = Double.parseDouble(parc.getText().toString());

            if (aaa == 0)
            {
                Toast.makeText(Kwadratowa.this, "Parametr A nie mo�e by� zerem!", Toast.LENGTH_SHORT) .show();
            }

            else
            {

            	double delta = (bbb * bbb - 4 * aaa * ccc);
               double pierwiastek = Math.sqrt(delta);


                if (delta == 0)
                {
                  double miejscezerowe = -bbb / (aaa * 2);
                  String mzero = String.format("%.2f", miejscezerowe);
                  wynik.setText("R�wnanie ma 1 rozwi�zanie:"+mzero);
                  zapiszwynik.setVisibility(View.VISIBLE);
                }

                else if (delta > 0)
                {
                  double x1 = (-bbb - pierwiastek) / (aaa * 2);
                  String mzero1=String.format("%.2f", x1);
                  double x2 = (-bbb + pierwiastek) / (aaa * 2);
                  String mzero2=String.format("%.2f", x2);
                  wynik.setText("R�wnanie ma 2 rozwi�zania:"+ mzero1+";"+ mzero2);
                  zapiszwynik.setVisibility(View.VISIBLE);
                }

                else
                {
                	wynik.setText("Ujemna delta. Brak rozwi�za�.");
                   
                }


            }
            }
        catch (Exception e)
        {
            Toast.makeText(Kwadratowa.this, "Brak danych. Uzupe�nij je.", Toast.LENGTH_SHORT).show();
        }

	}
	//----------------------------------------------------------------------------
		public void zapiszwynik(View view) {
			//	Button zapisz;
				EditText para=(EditText)findViewById(R.id.editText1);
				EditText parb=(EditText)findViewById(R.id.editText2);
				EditText parc=(EditText)findViewById(R.id.editText3);
				EditText wynik=(EditText)findViewById(R.id.editText4);
				final DatabaseHelper db = new DatabaseHelper(this);
		    	String w = wynik.getText().toString();
		    	String a = para.getText().toString();
		       	String b = parb.getText().toString();
		       	String c = parc.getText().toString();
		      // 	zapisz = (Button)findViewById(R.id.button2);
		    	
		    	if (a != "" && b != "" && c != "" && w != ""){
		    		db.dodajRownanie(new Rownania("y="+a+"x^2+"+b+"x+"+c, w));
		    		para.getText().clear();   
					parb.getText().clear(); 
					parc.getText().clear();
					wynik.setText("");
		    		Toast.makeText(getApplicationContext(), "Zapisano!", Toast.LENGTH_SHORT).show();
		    		zapiszwynik.setVisibility(View.INVISIBLE);
		    	}

    };


	
//----------------------------------------------------------------------

	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.kwadratowa, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

