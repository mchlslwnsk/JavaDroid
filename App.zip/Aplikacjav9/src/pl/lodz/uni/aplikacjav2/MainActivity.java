package pl.lodz.uni.aplikacjav2;



import android.app.Activity;
//import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

//import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
 
 
public class MainActivity extends Activity{
	
	ListView list;
	
	 String[] nazwa ={
			"Funkcja liniowa",
			"Funkcja kwadratowa",
			"Funkcja 3-go stopnia",
			"Baza obliczen",
		};
	 
	 public String[] opis ={
			"Obliczanie miejsca zerowego r�wnania liniowego",
			"Obliczanie pierwiastk�w r�wnania kwadratowego",
			"Obliczanie pierwiastk�w r�wnania trzeciego stopnia",
			"Wy�wietla zapisane wcze�niej r�wnania",

	 };

	String[] toast = {
					"Funkcja liniowa f(x)= ax + b,",
					"Funkcja kwadratowa f(x) = ax^2 + bx + c",
					"Funkcja 3go stopnia ax^3+bx^2+cx+d=0",
					"Baza wykonanych obliczen.",

			
		};
	Integer[] ikona={
			R.drawable.linia1,
			R.drawable.kwadrat1,
			R.drawable.trojka,
			R.drawable.database,


	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//Adapter w ListView tworzy element od nowa gdy tylko zniknie z ekranu
		ListAdapter adapter=new ListAdapter(this, nazwa, opis, toast, ikona);
		list=(ListView)findViewById(R.id.list);
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(new OnItemClickListener() {
		
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				 switch(position)
				 {
				 case 0:  Intent newActivity0 = new Intent(MainActivity.this, Liniowa.class);     
	              startActivity(newActivity0);
	              break;
				 case 1:  Intent newActivity1 = new Intent(MainActivity.this, Kwadratowa.class);     
	              startActivity(newActivity1);
	              break;
				 case 2:  Intent newActivity2 = new Intent(MainActivity.this, Trojka.class);     
	              startActivity(newActivity2);
	              break;
				 case 3:  Intent newActivity3 = new Intent(MainActivity.this, Baza.class);     
	              startActivity(newActivity3);
	              break;
				 }
				
				//TODO Auto-generated method stub
				// po przejsciu
				String Selecteditem= nazwa[+position];
				Toast.makeText(getApplicationContext(), Selecteditem, Toast.LENGTH_SHORT).show();
				
				
			}
			
		});
		list.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
				//toast z listy
			public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
				String Selecteditem= toast[+position];
				Toast.makeText(getApplicationContext(), Selecteditem, Toast.LENGTH_SHORT).show();
				

				return true;
			}
		});
	}
		
}