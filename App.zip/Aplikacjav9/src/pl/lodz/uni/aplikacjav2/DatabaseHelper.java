package pl.lodz.uni.aplikacjav2;

import java.util.LinkedList;
import java.util.List; 
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
//tworzenie i aktualizowanie bazy
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "BazaRownan";
 
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);  
    }
 //http://www.android4devs.pl/2011/07/sqlite-androidzie-kompletny-poradnik-dla-poczatkujacych/
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_EQUATION_TABLE = "CREATE TABLE equations ( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " + 
                "eq TEXT, "+
                "solution TEXT )";
 
        db.execSQL(CREATE_EQUATION_TABLE);
    }
 
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS equations");
        this.onCreate(db);
    }
    
    //pola statyczne opisujace baze 
    private static final String TABLE_ROWNAN = "equations";  
    private static final String KEY_ID = "id";
    private static final String KEY_EQ = "eq";
    private static final String KEY_SOLUTION = "solution"; 
   // private static final String[] COLUMNS = {KEY_ID,KEY_EQ,KEY_SOLUTION};
    // obsluga dodawania do rownania do bazy
    
    //nowy wpis
    public void dodajRownanie(Rownania rownanie){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues(); //sluzy do zapisywania danych/przekazania ich do zapisania
        values.put(KEY_EQ, rownanie.getEq()); 
        values.put(KEY_SOLUTION, rownanie.getSolution()); 
        db.insert(TABLE_ROWNAN,
                null,
                values);
        db.close(); 
    }
    
    //lista wszystkich rownan w bazie
    public List<Rownania> getWszystkieRownania() {
        List<Rownania> rownania = new LinkedList<Rownania>(); //odnosniki
        String query = "SELECT  * FROM " + TABLE_ROWNAN;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null); //kursor, ustawia wybor w adapterze, przemiesza sie po wynikach
        Rownania rownanie = null;
        if (cursor.moveToFirst()) { //nawigacja po danych
            do {
                rownanie = new Rownania();
                rownanie.setId(Integer.parseInt(cursor.getString(0)));
                rownanie.setEq(cursor.getString(1));
                rownanie.setSolution(cursor.getString(2));
                rownania.add(rownanie);
            } while (cursor.moveToNext());
        }
        return rownania;
    }

    //string samego rownania
    public String[] getWartosciRownan(){
    	String query = "SELECT  * FROM " + TABLE_ROWNAN;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);    //kwerenda przeszukujaca    
    	String[] array = new String[cursor.getCount()];
    	int i = 0;
    	while(cursor.moveToNext()){
    	    String eqValue = cursor.getString(cursor.getColumnIndex(KEY_EQ));
    	    array[i] = eqValue;
    	    i++;
    	}
    	return array;    	
    }
    
    //string do wynikow
    public String[] getWynikiRownan(){
    	String query = "SELECT  * FROM " + TABLE_ROWNAN;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);  //odzysk z danych z tabeli       
    	String[] array = new String[cursor.getCount()];
    	int i = 0;
    	while(cursor.moveToNext()){ 
    	    String eqValue = cursor.getString(cursor.getColumnIndex(KEY_SOLUTION));
    	    array[i] = eqValue;
    	    i++;
    	}
    	return array;    	
    }
    
    
    public void usunRownanie(Rownania rownanie) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ROWNAN,
                KEY_ID+" = ?",
                new String[] { String.valueOf(rownanie.getId()) });
        db.close();
    }
}