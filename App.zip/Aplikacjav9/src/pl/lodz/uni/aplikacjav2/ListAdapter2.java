package pl.lodz.uni.aplikacjav2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import java.util.List;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
 
public class ListAdapter2 extends ArrayAdapter<String> {
 
	private final Activity context;
	final String[] itemRwn;
	final String[] itemWnk;
	
	public ListAdapter2(Activity context, String[] itemRwn, String[] itemWnk) {
		// TODO Auto-generated constructor stub
		super(context, R.layout.mojalista2, itemRwn);		
		this.context=context;
		this.itemRwn=itemRwn;
		this.itemWnk=itemWnk;
	}
	@SuppressLint("ViewHolder")
	public View getView(final int position,View view,ViewGroup parent) {
		
		LayoutInflater inflater=context.getLayoutInflater(); //dynamicznie �adowany layout
		View rowView=inflater.inflate(R.layout.mojalista2, null,true);
		final DatabaseHelper sqlHelper = new DatabaseHelper(context);
		final List<Rownania> list = sqlHelper.getWszystkieRownania();
		TextView txtTitle = (TextView) rowView.findViewById(R.id.item2);		
		txtTitle.setText(itemRwn[position]);
		
		
		Button button = (Button) rowView.findViewById(R.id.usunrekord);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

            	sqlHelper.usunRownanie(list.get(+position));
            	Toast.makeText(context, "Usunieto!", Toast.LENGTH_SHORT).show();            	
            	Intent nowaCzystaBaza = new Intent(context, Baza.class);
	            context.startActivity(nowaCzystaBaza); 
            }
        });
		return rowView;
	};
}