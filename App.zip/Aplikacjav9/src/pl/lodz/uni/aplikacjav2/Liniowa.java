package pl.lodz.uni.aplikacjav2;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Liniowa extends Activity {
	Button zapiszwynik;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_liniowa);
		zapiszwynik = (Button)findViewById(R.id.buttonzapisz1);
	}
	
//	---------------------------------------------------------------------------
	public void liniowa(View view){
		zapiszwynik = (Button)findViewById(R.id.buttonzapisz1);
		EditText para=(EditText)findViewById(R.id.editText1);
		EditText parb=(EditText)findViewById(R.id.editText2);
		EditText wynik=(EditText)findViewById(R.id.editText4);
		
		try {

			double aaa = Double.parseDouble(para.getText().toString());
            double bbb = Double.parseDouble(parb.getText().toString());
            if (aaa == 0)
            {
                Toast.makeText(Liniowa.this, "Parametr A nie mo�e by� zerem!", Toast.LENGTH_SHORT) .show();
            }

            else
            {

            	double miejscezerowe = (-bbb/aaa);
            	String mzero = String.format("%.2f", miejscezerowe);
            	//wynik.setText(mzero);
            	wynik.setText("Rozwiazanie:"+mzero);
            	zapiszwynik.setVisibility(View.VISIBLE);

            }
            }
        catch (Exception e)
        {
            Toast.makeText(Liniowa.this, "Brak danych. Uzupelnij je", Toast.LENGTH_SHORT).show();
        }

    }
//	----------------------------------------------------------------------
	
	
	public void zapiszwynik2(View view) {
		//	Button zapisz;
			EditText para=(EditText)findViewById(R.id.editText1);
			EditText parb=(EditText)findViewById(R.id.editText2);
			EditText wynik=(EditText)findViewById(R.id.editText4);
			final DatabaseHelper db = new DatabaseHelper(this);
	    	String w = wynik.getText().toString();
	    	String a = para.getText().toString();
	       	String b = parb.getText().toString();
	      // 	zapisz = (Button)findViewById(R.id.button2);
	    	
	    	if (a != "" && b != "" && w != ""){
        		db.dodajRownanie(new Rownania("y="+a+"x+"+b, w));
	    		//Toast.makeText(getApplicationContext(), "Zapisano!", Toast.LENGTH_SHORT).show();
	    		zapiszwynik.setVisibility(View.INVISIBLE);
	    		para.getText().clear();   
				parb.getText().clear(); 
				wynik.setText("");
	    		Toast.makeText(getApplicationContext(), "Zapisano!", Toast.LENGTH_SHORT).show();
	    	}
	    /*	else
	    	{
	    		Toast.makeText(getApplicationContext(), "Popraw! Nie zapisano!", Toast.LENGTH_SHORT).show();
	    	}
*/
};
	
	//--------------------------------------------------------
	
	
	
	
	
	
		
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.liniowa, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
