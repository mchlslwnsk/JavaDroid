package pl.lodz.uni.aplikacjav2;


public class Rownania {
	private int id;
	// id
    private String eq;
    private String solution;
    //rownanie
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEq() {
		return eq;
	}

	public void setEq(String eq) {
		this.eq = eq;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	
 
    public Rownania(){}
 
    public Rownania(String eq, String solution) {
        super();
        this.eq = eq;
        this.solution = solution;
    }

    @Override
    public String toString() {
        return "Rownanie [id=" + id + ", eq=" + eq + ", solution=" + solution
                + "]";
    }
}
    
