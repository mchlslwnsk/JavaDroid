package pl.lodz.uni.aplikacjav2;


import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Trojka extends Activity {
	Button zapiszwynik;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_trojka);
		zapiszwynik = (Button)findViewById(R.id.buttonzapisz3);
		
	}
	
	//-----------------------------------------------------------------------------
	public void trojka(View view){
		zapiszwynik = (Button)findViewById(R.id.buttonzapisz3);
		EditText para=(EditText)findViewById(R.id.editText1);
		EditText parb=(EditText)findViewById(R.id.editText2);
		EditText parc=(EditText)findViewById(R.id.editText3);
		EditText pard=(EditText)findViewById(R.id.editText5);
		EditText wynik=(EditText)findViewById(R.id.editText4);
		
		try {

			double aaa = Double.parseDouble(para.getText().toString());
			double bbb = Double.parseDouble(parb.getText().toString());
            double ccc = Double.parseDouble(parc.getText().toString());
            double ddd = Double.parseDouble(pard.getText().toString());
            

            if (aaa == 0)
            {
                Toast.makeText(Trojka.this, "To nie jest rownanie szczescienne. A nie moze byc 0!", Toast.LENGTH_SHORT) .show();
            }
            else
            {       	
              //  double hhhh=g^2/4+f3/27
            	double fff = (ccc/aaa)-(((bbb*bbb)/3)*(aaa*aaa));
                double ggg= (Math.pow(2*bbb,3))/(Math.pow(27*aaa,3))-((bbb*ccc)/((3*aaa)*(3*aaa))+(ddd/aaa));
                double hhh = ggg/2+fff/3;
                
            	if (hhh > 0)
            		{	
	            	double g3 = ((-ggg)/2);
	            	double h3 = Math.sqrt(hhh);
	            	double miejscezerowe1 = Math.pow((g3+h3),1/3)+Math.pow((g3-h3), 1/3)-(bbb/(3*aaa));
	                String mzero1 = String.format("%.2f", miejscezerowe1);
	                wynik.setText("R�wnanie ma 1 pierw.rzeczyw.:"+mzero1);
	                zapiszwynik.setVisibility(View.VISIBLE);
           
            		}
            	else
            	{
            		 if (fff==0 && ggg==0)
            		{
            			double miejscezerowe2 = Math.pow((-ddd/aaa), 3);
            			String mzero2 = String.format("%.2f", miejscezerowe2);
            			wynik.setText("R�wnanie ma 1pierw.potrojny:"+mzero2);
            			zapiszwynik.setVisibility(View.VISIBLE);
            		}
            	
            		 else
            		 	{
	            		double iii = Math.sqrt((ggg/2)-hhh);
	                	double jjj = Math.pow(iii, 3);
	                	double kkk = Math.acos((-ggg)/2*iii);
	                	double mmm = Math.cos(kkk/3);
	                	double nnn = Math.sqrt(3)*Math.sin(kkk/3);
	                	double ppp = (-bbb/3*aaa);
	                	
	                	double miejscezerowe3 = 2*jjj*mmm+ppp;
	                	double mzero3 = (double) Math.round(miejscezerowe3 * 100.0) / 100.0;
	                	double miejscezerowe4 = ((-jjj)*(mmm+nnn))+ppp;
	                	double mzero4 = (double) Math.round(miejscezerowe4 * 100.0) / 100.0;
	                	double miejscezerowe5 = ((-jjj)*(mmm-nnn))+ppp;
	                	double mzero5 =(double) Math.round(miejscezerowe5 * 100.0) / 100.0;
	                	wynik.setText("Trzy pierw.rzeczy.:"+mzero3+";"+mzero4+";"+mzero5);
	                	zapiszwynik.setVisibility(View.VISIBLE);
            		 	}
            		}
            	}
			}
        catch (Exception e)
        {
            Toast.makeText(Trojka.this, "Brak danych. Uzupe�nij je.", Toast.LENGTH_SHORT).show();
        }

    }
		//---------------------------------------------------------
	public void zapiszwynik(View view) {
		//	Button zapisz;
			EditText para=(EditText)findViewById(R.id.editText1);
			EditText parb=(EditText)findViewById(R.id.editText2);
			EditText parc=(EditText)findViewById(R.id.editText3);
			EditText pard=(EditText)findViewById(R.id.editText5);
			EditText wynik=(EditText)findViewById(R.id.editText4);
			final DatabaseHelper db = new DatabaseHelper(this);
	    	String w = wynik.getText().toString();
	    	String a = para.getText().toString();
	       	String b = parb.getText().toString();
	       	String c = parc.getText().toString();
	    	String d = pard.getText().toString();
	      // 	zapisz = (Button)findViewById(R.id.button2);
	    	
	    	if (a != "" && b != "" && c != "" && d != "" && w != ""){
        		db.dodajRownanie(new Rownania("y="+a+"x^3+"+b+"x^2+"+c+"x+"+d, w));
	    	para.getText().clear();   
			parb.getText().clear(); 
			parc.getText().clear();
			pard.getText().clear();
			wynik.setText("");
        		Toast.makeText(getApplicationContext(), "Zapisano!", Toast.LENGTH_SHORT).show();
        		zapiszwynik.setVisibility(View.INVISIBLE);
        	}
	    	};

	//--------------------------------------------------------

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.trojka, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

